# -*- coding: utf-8 -*-
"""
Created on Thu Jan 21 09:39:21 2021

@author: khall
"""

import numpy as np
import matplotlib.pyplot as plt
#import cmath as cm
import time

plt.close('all')

N = 10000
s = 1
l = 0.01

m_x = -1
M_x = 1
m_y = -1
M_y = 1

f = 3 #combien de fonctions j'étudie

# def ker0(x,y,s,l):
#     return( s*np.exp(-np.abs(x-y)/l) )

def ker0(r,s,l):
    return( s*np.exp(-np.abs(r)/l) )

# def ker1(x,y,s,l):
#     return( s*np.exp(-0.5*(x-y)*(x-y)/(l*l)) )

def ker1(r,s,l):
    return( s*np.exp(-0.5*(r)*(r)/(l*l)) )

# def ker2(x,y,s,l) :
#     return( s*(1 + np.sqrt(5)*np.abs(x-y)/l + 5*np.abs(x-y)*np.abs(x-y)/(3*l*l)) * np.exp(-np.sqrt(5)*np.abs(x-y)/l) )

def ker2(r,s,l):
    return( s*(1 + np.sqrt(5)*np.abs(r)/l + 5*np.abs(r)*np.abs(r)/(3*l*l)) * np.exp(-np.sqrt(5)*np.abs(r)/l) )


def mat_ker_first_row(min_x,min_y,max_Y,fct_ker,s,l,n):
    M_k1 = np.zeros(n+1, dtype=complex)
    Y = np.linspace(min_y,max_Y,n+1)
    # for i in range(0,n+1):
    #     M_k1[i] = fct_ker(min_x,Y[i],s,l)
    M_k1 = fct_ker(np.subtract.outer(min_x,Y),s,l)
    return M_k1


#u = np.random.normal(l,s,N)
"""
K = np.zeros((a,N))
K[0] = mat_ker_first_row(m_x,m_y,M_y,ker0,s,l,N)
K[1] = mat_ker_first_row(m_x,m_y,M_y,ker1,s,l,N)
K[2] = mat_ker_first_row(m_x,m_y,M_y,ker2,s,l,N)
"""

def mat_circ_first_row(min_x,min_y,max_Y,fct_ker,s,l,n):
    a = np.zeros(2*n, dtype=complex)
    c = mat_ker_first_row(min_x,min_y,max_Y,fct_ker,s,l,n)
    #a[0::2] = c
    #a[N:2*N] = [c[N-1-i] for i in range(1,N-1)]
    a = np.concatenate((c, [c[n-1-i] for i in range(n-1)]))
    return a


temps = np.zeros(N-3)

for h in range(3,N):
    temps[h-3] = time.process_time()
    a = np.zeros((f,2*h), dtype=complex)
    a[0] = mat_circ_first_row(m_x,m_y,M_y,ker0,s,l,h)
    a[1] = mat_circ_first_row(m_x,m_y,M_y,ker1,s,l,h)
    a[2] = mat_circ_first_row(m_x,m_y,M_y,ker2,s,l,h)
    
    # def transf_fourier(n):
    #     F = np.zeros((2*n,2*n), dtype=complex)
    #     b = np.exp(-np.pi*1j/n)
    #     for k in range(2*n):
    #         for m in range(k,2*n):
    #             F[k,m] = np.power(b,(k*m))
    #             F[m,k] = F[k,m]
    #     return F
    
    # F = transf_fourier(N)
    
    #np.isclose(np.dot(F,F.conj().T)/2/N,np.eye(2*N),1e-5)
    
    # S = np.zeros((f,2*N), dtype=complex)
    # for i in range(f):
    #     # S[i] = np.dot(F,a[i])
    #     S[i] = np.fft.fft(a[i])
    
    
    # D = np.zeros((f,2*N,2*N), dtype=complex)
    # for i in range(f):
    #     D[i] = np.diag(S[i])
    
    # D = np.zeros((f,2*N), dtype=complex)
    # for i in range(f):
    #     D[i] = np.fft.fft(a[i])
    
    D_05 = np.zeros((f,2*h), dtype=complex)
    for i in range(f):
        D_05[i] = np.power(np.fft.fft(a[i]),0.5)
    
    # D_05 = np.power(D,0.5)
    
    theta_re = np.random.normal(0,1,2*h)
    theta_im = np.random.normal(0,1,2*h)
    theta = np.zeros(2*h, dtype=complex)
    theta = theta_re+theta_im*1j
    
    # C_star = np.zeros((f,2*N,2*N), dtype=complex)
    # for i in range(f):
    #     C_star[i] = np.dot(F.conj().T,np.power(D[i],0.5))/np.sqrt(2*N)
    
    Y = np.zeros((f,2*h), dtype=complex)
    for i in range(f):
        # Y[i] = (1/np.sqrt(2*h))*np.fft.ifft(D_05[i]*theta)
        Y[i] = np.sqrt(h)*np.fft.ifft(D_05[i]*theta)
    
    Y_1 = np.zeros((f,h+1))
    for i in range(f):
        Y_1[i] = np.real(Y[i][0:h+1])
        
    Y_2 = np.zeros((f,h+1), dtype=complex)
    for i in range(f):
        Y_2[i] = np.imag(Y[i][0:h+1])
        
    temps[h-3] = time.process_time() - temps[h-3]
    print(h)

plt.figure()
plt.plot(range(3,N),temps)
plt.title("Temps d'exécution en fonction de N")
plt.xlabel("N")
plt.ylabel("Temps")

h = N-1
for i in range(f):
    x = []
    y = []
    x = x +["GP"+"$1_" + str(i)+"$"]
    y = y +["GP"+"$2_" + str(i)+"$"]
    plt.figure()
    plt.plot(np.linspace(m_x,M_x,h+1), Y_1[i])
    plt.legend(x)
    plt.title("Trajectoire "+str(i)+" du GP z")
    plt.xlabel("x")
    plt.ylabel("z(x)")
    # plt.figure()
    # plt.plot(np.linspace(m_x,M_x,N+1), Y_2[i])
    # plt.legend(y)
    


