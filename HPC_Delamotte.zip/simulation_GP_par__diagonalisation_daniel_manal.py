# -*- coding: utf-8 -*-
"""
Created on Thu Feb  4 01:47:59 2021

@author: khall
"""
import numpy as np
import matplotlib.pyplot as plt
import time


plt.close('all')

N = 500
s = 1
l = 0.01

m_x = -1
M_x = 1
m_y = -1
M_y = 1

f = 3 #combien de fonctions j'étudie

def ker0(r,s,l):
    return( s*np.exp(-np.abs(r)/l) )

# def ker1(x,y,s,l):
#     return( s*np.exp(-0.5*(x-y)*(x-y)/(l*l)) )

def ker1(r,s,l):
    return( s*np.exp(-0.5*(r)*(r)/(l*l)) )

# def ker2(x,y,s,l) :
#     return( s*(1 + np.sqrt(5)*np.abs(x-y)/l + 5*np.abs(x-y)*np.abs(x-y)/(3*l*l)) * np.exp(-np.sqrt(5)*np.abs(x-y)/l) )

def ker2(r,s,l):
    return( s*(1 + np.sqrt(5)*np.abs(r)/l + 5*np.abs(r)*np.abs(r)/(3*l*l)) * np.exp(-np.sqrt(5)*np.abs(r)/l) )


def mat_ker(min_x,max_X,min_y,max_Y,fct_ker,s,l,n):
    M_k1 = np.zeros((n,n))
    X = np.linspace(min_x,max_X,n)
    Y = np.linspace(min_y,max_Y,n)
    # for i in range(0,n):
    #     for j in range(0,n):
    #         M_k1[i][j] = fct_ker(X[i],Y[j],s,l)
    M_k1 = fct_ker(np.subtract.outer(X,Y),s,l)
    return M_k1

temps = np.zeros(N-3)

for h in range(3,N):
    temps[h-3] = time.process_time()
    u = np.random.normal(l,s,h)
    
    K = np.zeros((f,h,h))
    K[0] = mat_ker(m_x,M_x,m_y,M_y,ker0,s,l,h)
    K[1] = mat_ker(m_x,M_x,m_y,M_y,ker1,s,l,h)
    K[2] = mat_ker(m_x,M_x,m_y,M_y,ker2,s,l,h)
    
    a = np.zeros((f, 1, h))
    b = np.zeros((f, h, h))
    for i in range(0,f) :
        a[i], b[i] = np.linalg.eig(K[i])
    
    z = np.zeros((f,1,h))
    for i in range(0,f) :
        z[i] = b[i]@np.diag(a[i][0])**(1/2)@u
    
    # vp = np.zeros((a,1,h))
    # for i in range(0,a):
    #     vp[i] = -np.sort(-np.linalg.eigvals(K[i]))
    
    # p = 8
    # eps = np.array([0])
    # for i in range(0,p):
    #     eps = np.concatenate((eps,np.array([10**-i])))
    
    # vp_hat = np.zeros((a,p,1,h))
    # for i in range(0,a):
    #     for j in range(0,p) :
    #         tmp_vp = np.linalg.eigvals(K[i]+vp[i][0][0]*eps[j]*np.eye(h))
    #         tmp_vp = -np.sort(-tmp_vp)
    #         vp_hat[i][j] = np.log10(tmp_vp / tmp_vp[0] )
    
    temps[h-3] = time.process_time() - temps[h-3]
    print(h)
    
    
    # leg1 = []
    # for i in range(0,a) :
    #     leg1 = leg1 + ['$K_'+str(i)+"$"]
    
    # for i in range(0,a):
    #     leg2 = []
    #     leg2 = leg2 + [leg1[i]]
    #     for j in range(1,p):
    #         leg2 = leg2 + [leg1[i]+'+'+'$v_0 \\times $'+str(eps[j])+' $\\times Id$']
    #     # normaliser les valeurs propres par la plus grande (v0), vhat = vi/v0, tracer(n, log10(vhat_n) )
    #     plt.figure(figsize=(8,5))
    #     for j in range(0,p) :
    #         plt.plot(range(N),vp_hat[i][j][0])
    #     plt.title('Etude des valeurs propres de '+leg1[i])
    #     plt.xlabel('Numéro de la valeur propre')
    #     plt.ylabel('Valeur propre normalisée')
    #     plt.legend(leg2)
    #     plt.show()
    
    # for i in range(0,a) :
    #     # tracer les valeurs propres de la matrice K : v0, v1, ..,vN-1
    #     plt.figure(figsize=(8,5))
    #     plt.plot(range(i),vp[i][0])
    #     plt.title("Valeurs propres")
    #     plt.xlabel('Numéro de la valeur propre')
    #     plt.ylabel('Valeur propre')
    #     plt.legend(leg1)
    #     plt.show()
    
    # for i in range(f):
    #     plt.figure()
    #     plt.plot(np.linspace(-1,1,h), z[i][0])
    #     plt.title("Trajectoire "+str(i)+" du GP z")
    #     plt.xlabel("x")
    #     plt.ylabel("z(x)")
    
plt.figure()
plt.plot(range(3,N),temps)
plt.title("Temps d'exécution en fonction de N")
plt.xlabel("N")
plt.ylabel("Temps")

for i in range(f):
    plt.figure()
    plt.plot(np.linspace(-1,1,h), z[i][0])
    plt.title("Trajectoire "+str(i)+" du GP z")
    plt.xlabel("x")
    plt.ylabel("z(x)")