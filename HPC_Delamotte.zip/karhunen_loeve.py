# -*- coding: utf-8 -*-
"""
Created on Thu Feb 11 05:30:40 2021

@author: Daniel
"""

import numpy as np
import matplotlib.pyplot as plt
import time 

plt.close('all')

N = 500
s = 1
l = 0.05
m_D = -1
M_D = 1
h = (M_D-m_D)/N


# def ker0(x,y,s,l):
#     return( s*np.exp(-np.abs(x-y)/l) )
# def ker0_r(r,s,l):
#     return( s*np.exp(-np.abs(r)/l) )

# def ker0(x,y,s,l):
#     return( s*np.exp(-np.abs(x-y)/l) )

def ker0(r,s,l):
    return( s*np.exp(-np.abs(r)/l) )

# def ker1(x,y,s,l):
#     return( s*np.exp(-0.5*(x-y)*(x-y)/(l*l)) )

def ker1(r,s,l):
    return( s*np.exp(-0.5*(r)*(r)/(l*l)) )

# def ker2(x,y,s,l) :
#     return( s*(1 + np.sqrt(5)*np.abs(x-y)/l + 5*np.abs(x-y)*np.abs(x-y)/(3*l*l)) * np.exp(-np.sqrt(5)*np.abs(x-y)/l) )

def ker2(r,s,l):
    return( s*(1 + np.sqrt(5)*np.abs(r)/l + 5*np.abs(r)*np.abs(r)/(3*l*l)) * np.exp(-np.sqrt(5)*np.abs(r)/l) )

# Nb de noyaux
a = 3
temps = np.zeros(N-3)
for n in range(3,N) :
    temps[n-3] = time.process_time()
    # Karhunen Loève
    # Discrétisation du problème intégral par la méthode du point milieu
    # Discrétisation selon X et Y : point milieu
    X = [m_D+0.5*(2.0*j+1)*h for j in range(0,n)]
    
    def mat_ker(X,Y,fct_ker,s,l):
        if (len(X) != len(Y)):
            raise Exception("Discrétisations ne sont pas de la même taille")
        """
        n = len(X)
        K = np.zeros((n,n))
        for i in range(n):
            for j in range(i,n):
                K[i][j] = fct_ker(X[i],Y[j],s,l)
                K[j][i] = K[i][j]
        """
        K = fct_ker(np.subtract.outer(X,Y),s,l)
        return(K)
    
    
    
    K = np.zeros((a,n,n))
    K[0] = h*mat_ker(X,X,ker0,s,l) 
    K[1] = h*mat_ker(X,X,ker1,s,l) 
    K[2] = h*mat_ker(X,X,ker2,s,l) 
    """
    val_p,Vect_P = np.linalg.eig(K)
    idx = val_p.argsort()[::-1]   
    val_p = val_p[idx]
    Vect_P = Vect_P[:,idx]
    """
    Vect_P = np.zeros((a,n,n))
    val_p = np.zeros((a,n))
    for i in range (0,a):
        Vect_P[i],val_p[i],Xxxx = np.linalg.svd(K[i])
        Vect_P[i] = Vect_P[i] / np.sqrt(h)
    # Choix de la troncature : M doit être tel que 
    # Var(Z) = 0.95 tr(K)
    # ie, np.sum(val_p[0:M+1]) = 0.95*tr(K)
    M = np.zeros(a,dtype=int)
    seuil = 0.95
    vals_sign = np.zeros(a)
    tr = np.zeros(a)
    for i in range (0,a):
        tr[i] = np.trace(K[i])
        while ( np.sum(val_p[i][0:M[i]])<seuil*tr[i] ) :
            M[i]=M[i]+1
    M_MAX = max(M)
    # Ne prendre en compte que les M 1ères vp ? Commenté = oui
    # M[:] = n
    # M_MAX = n
    
    
    # Réalisations de la loi normale centrée réduite
    z = np.random.normal(0,1,M_MAX)
    
    # Assemblage du P.G. Z
    Z = np.zeros((a,n))
    for ii in range(0,a):
        for i in range(0,n):
            Z[ii,i] = 0
            for j in range(0,M[ii]):
                Z[ii,i] = Z[ii,i] + np.sqrt(val_p[ii,j])*Vect_P[ii,i,j]*z[j]
    
    temps[n-3] = time.process_time() - temps[n-3]
    print(n)

plt.figure()
plt.plot(range(3,N),temps)
plt.title("Temps d'exécution en fonction de N")
plt.xlabel("N")
plt.ylabel("Temps")

# print(Z)
for i in range(0,a):
    plt.figure()
    plt.plot(X, Z[i])
    plt.title("Trajectoire "+str(i)+" du GP z")
    plt.xlabel("x")
    plt.ylabel("z(x)")
